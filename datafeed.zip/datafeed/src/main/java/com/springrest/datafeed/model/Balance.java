package com.springrest.datafeed.model;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
import lombok.experimental.Accessors;
import javax.persistence.*;
import java.util.HashSet;
import java.util.Set;


@Setter
@Getter
@Accessors(chain = true)
@Entity(name = "Balance")
@ToString
@Table(
        name = "balance",
        uniqueConstraints = {
                @UniqueConstraint(name = "balance_account_number_unique", columnNames = "account_number")
        }
)
public class Balance extends BaseEntity{

    @Column(name = "account_number",
            unique = true,
            nullable = false,
            updatable = false
    )
    private String accountNumber;

    @Column(
            name = "balance_amount",
            updatable = true,
            nullable = false
    )
    private Double balanceAmount = 0.0;

    @OneToMany(cascade = CascadeType.ALL)
    @JoinColumn(
            name = "account_id",
            nullable = false,
            referencedColumnName = "id"
            )
    private Set<Transaction> transactions = new HashSet<>();

}
