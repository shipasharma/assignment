package com.springrest.datafeed.service;


public interface JpaService<T, Long>  {
    T save(T object);
}
