package com.springrest.datafeed.model;

import lombok.AccessLevel;
import lombok.Getter;
import lombok.Setter;
import lombok.experimental.Accessors;
import org.springframework.data.annotation.CreatedDate;

import javax.persistence.*;
import java.io.Serializable;
import java.time.Instant;

@Setter
@Getter
@Accessors(chain = true)
@MappedSuperclass
public class BaseEntity implements Serializable {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Setter(AccessLevel.NONE)
    @Column(
            name = "id",
            updatable = false,
            nullable = false
    )
    private Long id;

    @CreatedDate
    @Setter(AccessLevel.NONE)
    @Column(
            name = "last_update_timestamp",
            updatable = false,
            nullable = false
    )
    private Instant lastUpdateTimestamp;

    @PrePersist
    void init(){
        this.lastUpdateTimestamp = Instant.now();
    }
}
