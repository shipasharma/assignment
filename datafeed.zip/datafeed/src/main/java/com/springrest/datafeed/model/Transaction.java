package com.springrest.datafeed.model;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
import lombok.experimental.Accessors;
import javax.persistence.*;

@Setter
@Getter
@Accessors(chain = true)
@Entity(name = "Transaction")
@ToString
@Table(name = "transaction")
public class Transaction extends BaseEntity{

    @Column(
            name = "transaction_type",
            nullable = false
    )
    private String type;

    @Column(
            name = "amount",
            updatable = true,
            nullable = false
    )
    private Double amount = 0.0;

}
