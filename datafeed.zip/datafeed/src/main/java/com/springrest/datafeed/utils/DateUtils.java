package com.springrest.datafeed.utils;

import java.time.Instant;
import java.time.LocalDate;
import java.time.ZoneId;

public class DateUtils {


    public static Instant StringToInstant(String date) {
        LocalDate localStartDate = LocalDate.parse(date);
        Instant dateInstant = localStartDate.atStartOfDay(ZoneId.systemDefault()).toInstant();

        return dateInstant;
    }
 }
