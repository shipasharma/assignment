package com.springrest.datafeed;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DatafeedApplication {

	public static void main(String[] args) {
		SpringApplication.run(DatafeedApplication.class, args);
	}

}
