package com.springrest.datafeed.service;

import com.springrest.datafeed.model.Transaction;

import java.time.Instant;
import java.util.Set;

public interface TransactionService extends JpaService<Transaction, String>{
    Set<Transaction> findAllByByAccountNumberBetween(String accountNumber, Instant startDate,
                                                     Instant endDate, String transactionType);
}
