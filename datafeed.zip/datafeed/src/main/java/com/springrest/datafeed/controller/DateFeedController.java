package com.springrest.datafeed.controller;

import com.springrest.datafeed.model.Transaction;
import com.springrest.datafeed.service.BalanceService;
import com.springrest.datafeed.service.TransactionService;
import com.springrest.datafeed.utils.DateUtils;
import lombok.extern.log4j.Log4j2;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import java.time.Instant;
import java.util.Set;

@RestController
@Log4j2
public class DateFeedController {

    private final BalanceService balanceService;
    private final TransactionService transactionService;


    public DateFeedController(BalanceService balanceService, TransactionService transactionService) {
        this.balanceService = balanceService;
        this.transactionService = transactionService;
    }

    @GetMapping("/getBalance/{accountNumber}")
    public ResponseEntity<?> getBalance(@PathVariable String accountNumber) {
        return new ResponseEntity<>(balanceService.findBalanceByAccountNumber(accountNumber), HttpStatus.ACCEPTED);
    }

    @GetMapping("/getTransactions/{accountNumber}/{startDate}/{endDate}/{transactionType}")
    public ResponseEntity<?> getTransactionsBetween(@PathVariable String accountNumber,
                                                    @PathVariable String startDate,
                                                    @PathVariable String endDate,
                                                    @PathVariable String transactionType) {
        Instant startDateInstant = DateUtils.StringToInstant(startDate);
        Instant endDateInstant = DateUtils.StringToInstant(endDate);
        Set<Transaction> transactionSet = transactionService.findAllByByAccountNumberBetween(accountNumber,
                startDateInstant,
                endDateInstant,
                transactionType.toUpperCase());
        return new ResponseEntity<>(transactionSet, HttpStatus.ACCEPTED);
    }

}
