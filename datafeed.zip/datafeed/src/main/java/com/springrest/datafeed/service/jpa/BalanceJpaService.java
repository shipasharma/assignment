package com.springrest.datafeed.service.jpa;

import com.springrest.datafeed.model.Balance;
import com.springrest.datafeed.repository.BalanceRepository;
import com.springrest.datafeed.service.BalanceService;
import org.springframework.stereotype.Service;

@Service
public class BalanceJpaService implements BalanceService {

    private final BalanceRepository balanceRepository;

    public BalanceJpaService(BalanceRepository balanceRepository) {
        this.balanceRepository = balanceRepository;
    }

    @Override
    public Balance save(Balance data) {
        return balanceRepository.save(data);
    }

    @Override
    public Double findBalanceByAccountNumber(String accountNumber) {
        return balanceRepository.findBalanceAmountByAccountNumber(accountNumber)
                .orElse(0.0);
    }
}
