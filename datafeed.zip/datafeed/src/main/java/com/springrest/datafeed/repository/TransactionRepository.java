package com.springrest.datafeed.repository;

import com.springrest.datafeed.model.Transaction;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.time.Instant;
import java.util.Set;

public interface TransactionRepository extends JpaRepository<Transaction, String> {

    @Query(value = "select * from transaction t inner join balance b on b.id=t.account_id\n" +
            "where b.account_number=?1 and \n" +
            " t.last_update_timestamp between ?2 and ?3 and t.transaction_type=?4", nativeQuery = true)
    Set<Transaction> findAllByByAccountNumberBetween(String accountNumber, Instant startDate,
                                                     Instant endDate, String transactionType);


}



