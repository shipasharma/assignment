package com.springrest.datafeed.service.jpa;

import com.springrest.datafeed.model.Transaction;
import com.springrest.datafeed.repository.TransactionRepository;
import com.springrest.datafeed.service.TransactionService;
import org.springframework.stereotype.Service;

import java.time.Instant;
import java.util.Set;


@Service
public class TransactionJpaService implements TransactionService {

    private final TransactionRepository transactionRepository;

    public TransactionJpaService(TransactionRepository transactionRepository) {
        this.transactionRepository = transactionRepository;
    }

    @Override
    public Transaction save(Transaction object) {
        return transactionRepository.save(object);
    }

    @Override
    public Set<Transaction> findAllByByAccountNumberBetween(String accountNumber, Instant startDate, Instant endDate,
                                                            String transactionType) {
        return transactionRepository.findAllByByAccountNumberBetween(accountNumber, startDate, endDate,
                transactionType);
    }
}

