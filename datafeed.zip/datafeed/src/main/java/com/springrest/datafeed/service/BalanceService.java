package com.springrest.datafeed.service;

import com.springrest.datafeed.model.Balance;


public interface BalanceService extends JpaService<Balance, Long> {
    Double findBalanceByAccountNumber(String accountNumber);
//    Balance findBalanceByAccountNumberBetween(String accountNumber,
//                                              Instant startDate, Instant endDate, TransactionType transactionType);

}
