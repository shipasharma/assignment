package com.springrest.datafeed.utils;

import com.springrest.datafeed.model.Balance;
import com.springrest.datafeed.model.Transaction;
import com.springrest.datafeed.service.BalanceService;
import com.springrest.datafeed.service.TransactionService;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import java.util.HashSet;
import java.util.Set;


@Component
public class Bootloader implements CommandLineRunner {
    private final TransactionService transactionService;
    private final BalanceService balanceService;

    public Bootloader(TransactionService transactionService, BalanceService balanceService) {
        this.transactionService = transactionService;
        this.balanceService = balanceService;
    }

    @Override
    public void run(String... args) {

            System.out.println("Loading data feeds..");
            //loadDataFeed();
    }

    private void loadDataFeed() {

        Set<Transaction> transactionSet = new HashSet<>();

        Transaction transaction1 = new Transaction()
                .setType("DEPOSIT")
                .setAmount(800.0);

        Transaction transaction2 = new Transaction()
                .setType("WITHDRAW")
                .setAmount(750.0);

        transactionSet.add(transaction1);
        transactionSet.add(transaction2);
        Balance balance = new Balance().setAccountNumber("abc013").setBalanceAmount(9000.0)
        .setTransactions(transactionSet);
        balanceService.save(balance);


    }
}
