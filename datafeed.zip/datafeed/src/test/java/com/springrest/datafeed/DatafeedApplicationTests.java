package com.springrest.datafeed;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DatafeedApplicationTests {

	@Test
	void contextLoads() {
	}

}
